# PROJETO ALERTA DENGUE -------------------------------------
# Auxiliar functions for nowcasting
# Leo Bastos 2020
# -----------------------------------------------------------

# Auxiliar function, sampling from a negative binomial likelihood
ff <- function(x, idx){
  rnbinom(n = idx, mu = exp(x$latent[idx]), size = x$hyperpar[1])
}

# Auxiliar function selecionando um pedaco do dataset
gg <- function(x, dados, idx, Fim.sat, Dmax){
  data.aux <- dados
  data.aux$Casos[idx] <- x
  data.aggregated <- data.aux %>%
    # Selecionando apenas os dias faltantes a partir
    # do domingo da respectiva ultima epiweek
    # com dados faltantes
    filter(Date >= Fim.sat - Dmax*7  ) %>%
    group_by(Date) %>%
    dplyr::summarise(
      Casos = sum(Casos)
    )
  data.aggregated
}


# Algorithm to get samples for the predictive distribution for the number of cases

nowcasting <- function(output.day, dadosRio.ag, Dm, Fim, seed = NULL, samples = 1000L,
                        inla_threads = 1L){
  if (!requireNamespace("INLA", quietly = TRUE)) {
    stop("nowcasting requires the optional package 'INLA'.", call. = FALSE)
  }
  index.missing = which(is.na(dadosRio.ag$Casos))


  # Step 1: Sampling from the approximate posterior distribution using INLA
  if (length(samples) != 1L || !is.numeric(samples) || samples < 1 || samples != floor(samples)) {
    stop("`samples` must be a positive integer.", call. = FALSE)
  }
  inla_threads <- .validate_workers(inla_threads, "inla_threads")
  .with_seed(seed, {
    srag.samples.list <- INLA::inla.posterior.sample(
      n = as.integer(samples), output.day,
      seed = if (is.null(seed)) 0L else max(1L, as.integer(seed)),
      num.threads = if (is.null(seed)) paste0(inla_threads, ":1") else "1:1",
      parallel.configs = FALSE
    )

    # Step 2: sample the missing triangle from the likelihood.
    vector.samples <- lapply(
      X = srag.samples.list, FUN = ff, idx = index.missing
    )

    # Step 3: aggregate each sampled triangle by onset date.
    tibble.samples <- lapply(
      X = vector.samples, FUN = gg, dados = dadosRio.ag,
      idx = index.missing, Fim.sat = Fim, Dmax = Dm
    )

    bind_rows(tibble.samples, .id = "sample")
  })
}


# Running INLA for the nowcasting model
nowcast.INLA <- function(dados.ag, model.day, workers = 1L, verbose = FALSE, ...,
                         inla_threads = workers){
  if (!requireNamespace("INLA", quietly = TRUE)) {
    stop("nowcast.INLA requires the optional package 'INLA'.", call. = FALSE)
  }

  inla_threads <- .resolve_concurrency_alias(
    workers, inla_threads, "inla_threads", !missing(workers), !missing(inla_threads)
  )
  output <- tryCatch(
    {INLA::inla(formula = model.day,
                 family = "nbinomial",
                 data = dados.ag,
                 num.threads = paste0(inla_threads, ":1"), verbose = verbose,
                 control.predictor = list(link = 1, compute = T),
                 control.compute = list( config = T),
                 ...
                 # control.family = list(
                 # hyper = list("theta" = list(
                 #   prior = "loggamma", param = c(1, 0.1)))
                 #   )
  )},
  error=function(cond) {
    stop("INLA fitting failed: ", conditionMessage(cond), call. = FALSE)
  })

  output
}


# Plot nowcasting
# plot.nowcast <- function(dadosRio.ag, pred.summy, nowcast = T){
#
#   dadosRio.ag.day.plot <- dadosRio.ag %>% group_by(Date) %>%
#     dplyr::summarise( Casos = sum(Casos, na.rm = T)) %>%
#     left_join(pred.summy, by = "Date") %>%
#     mutate(
#       Casos = ifelse(Date > Fim, NA, Casos),
#       Forecast = ifelse(is.na(Mean), NA, 0) + ifelse(Date > Fim, 1, 0)
#     )
#
#   # Time series
#   p0.day <- dadosRio.ag.day.plot %>%
#     ggplot(aes(x = Date, y = Casos,
#                color = "Casos notificados",
#                linetype = "Casos notificados")) +
#     geom_line(size = 1, na.rm = T)
#
#   if(nowcast){
#     p0.day <- p0.day +
#       geom_ribbon( aes( ymin=LI, ymax=LS), fill = 'gray',
#                    color = 'gray', alpha = 0.5,
#                    show.legend = F) +
#       geom_line(aes(x = Date, y = Median,
#                     colour = "Nowcasting",
#                     linetype = "Nowcasting"),
#                 size = 1, na.rm = T) +
#       scale_colour_manual(name = "",
#                           values = c("black", "black"),
#                           guide = guide_legend(reverse=F)) +
#       scale_linetype_manual(name = "",
#                             values = c("solid", "dotted"),
#                             guide = guide_legend(reverse=F))
#   }
#
#   p0.day <- p0.day +
#     #ylab("Casos hospitalização de SRAG") +
#     #xlab("Tempo") +
#     theme_bw( base_size = 14) +
#     theme( legend.position = c(0.2, 0.8), legend.title = element_blank())
#
#   p0.day
# }
