library(testthat)
library(AlertTools)

test_check("AlertTools")

