---
title: "Info Dengue Rio"
author: "Relatório de situação da dengue na cidade do Rio de Janeiro"
output: pdf_document
geometry: margin=0.5in
fontsize: 12pt
---







**Rio de Janeiro, 2016-05-19**


Confira a situação da dengue na cidade do Rio de Janeiro. Mais detalhes, ver: [info.dengue.mat.br](info.dengue.mat.br) 

## Índice {#top}
* [Mapa](#mapa)
* [Na cidade](#tab1)
* [Dados por APS](#aps)
* [Notas](#notas)

**Código de Cores do Alerta por APS**

*Verde (atividade baixa)*
   temperatura < 22 graus por 3 semanas 
   atividade de tweet normal (não aumentada)
   ausência de transmissão sustentada

*Amarelo (Alerta)*
   temperatura > 22C por mais de 3 semanas
   ou atividade de tweet aumentada

*Laranja (Transmissão sustentada)*
  número reprodutivo >1 por 3 semanas

*Vermelho (atividade alta)*
 incidência acima do percentil 90 (100:100.000 habitantes)

\newpage

### Mapa da Cidade do Rio de Janeiro {#mapa}

As sub-divisões são as áreas programáticas da saúde. Verde indica atividade baixa, amarelo indica vulnerabilidade, laranja indica transmissão sustentada e vermelho indica incidência acima do percentil 90.

<img src="figure/unnamed-chunk-3-1.pdf" title="plot of chunk unnamed-chunk-3" alt="plot of chunk unnamed-chunk-3" style="display: block; margin: auto;" />

Veja o mapa interativo em [Alerta Dengue](http://alerta.dengue.mat.br)
<br> </br>
<p> </p>

\newpage

<br> </br>

### <a name="tab1"></a> Situação da dengue na cidade do Rio de Janeiro




![plot of chunk unnamed-chunk-5](figure/unnamed-chunk-5-1.pdf) 


\newpage

Últimas 6 semanas:

- SE: semana epidemiológica
- casos: número de casos de dengue no SINAN
- casos_corrigidos: estimativa do número de casos notificados (ver [Notas](#notas))
- tweets: número de tweets relatando sintomas de dengue (ver [Notas](#notas))
- tmin: média das temperaturas mínimas da semana
- inc: incidência por 100.000 habitantes


---------------------------------------------------------------------
  se    casos   casos.estimados   ICmin   ICmax   inc   tweet   tmin 
------ ------- ----------------- ------- ------- ----- ------- ------
201614  2272         2272         2272    2272   34.95   72    24.57 

201615  1970         1970         1970    1970   30.31   17    24.71 

201616  1133         1133         1133    1133   17.43   14    23.86 

201617  1496         1496         1496    1496   23.02   20    21.86 

201618   430          712          642     733   6.615   21    19.86 

201619   181          518          453     538   2.785   14    21.57 
---------------------------------------------------------------------

\newpage


### Alerta por APS {#aps}
A linha tracejada verde indica o limiar pré-epidêmico; a linha tracejada vermelha indica o limiar de atividade alta (acima do qual é acionado o alerta vermelho). 

![plot of chunk unnamed-chunk-7](figure/unnamed-chunk-7-1.pdf) 

\newpage

![plot of chunk unnamed-chunk-8](figure/unnamed-chunk-8-1.pdf) 

\newpage
### Tabelas com os dados das últimas quatro semanas por APS

casos not = casos notificados, casos est = casos estimados após correção do atraso de notificação, tmin = temperatura mínima da semana, Rt = número reprodutivo, se maior que 1, indica que os casos estão com tendência de aumento, prob(Rt > 1) = p-valor do teste se Rt >1,
inc = incidência por 100.000 habitantes, nivel de 1 a 4 indica verde a vermelho.


```
## Área Programática da Saúde 1.0
```

<br> </br>


------------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt     prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------- ------------ ----- -------
201616     43          43      23.86  0.2012       0       18.95    2   

201617     37          37      21.86  0.2532       0       16.3     2   

201618     35          57      19.86  0.7172    0.02657    25.11    2   

201619      2           4      21.57  0.08273  7.891e-12   1.762    2   
------------------------------------------------------------------------



```
## Área Programática da Saúde 2.1
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     14          14      23.86  0.3596  0.0002104   2.533    2   

201617     27          27      21.86  0.9307    0.3933    4.885    2   

201618     23          36      19.86  1.555     0.9544    6.514    2   

201619      7          18      21.57  0.706     0.1249    3.257    1   
-----------------------------------------------------------------------




```
## Área Programática da Saúde 2.2
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     46          46      23.86  0.2402      0       12.39    2   

201617     58          58      21.86  0.3298  1.332e-15   15.63    2   

201618     54          90      19.86  0.8165    0.0758    24.25    2   

201619     47          140     21.57  1.793       1       37.72    2   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 3.1
```

<br> </br>

\newpage


-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     245         245     23.86  0.5888   1.07e-11   33.3     2   

201617     296         296     21.86  0.8812   0.05595    40.23    2   

201618     101         173     19.86  0.6284  5.911e-07   23.51    2   

201619     53          158     21.57  0.6448  6.594e-06   21.47    2   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 3.2
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     100         100     23.86  0.9078    0.2412    20.42    2   

201617     89          89      21.86  0.7948   0.05199    18.17    2   

201618     57          95      19.86  0.9182    0.2735    19.4     2   

201619      9          24      21.57  0.2629  4.049e-11   4.901    2   
-----------------------------------------------------------------------


```
## Área Programática da Saúde 3.3
```

<br> </br>


-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     98          98      23.86  0.4702  8.357e-11   10.6     2   

201617     137         137     21.86  0.7826   0.01541    14.82    2   

201618     28          45      19.86  0.3365  5.026e-12   4.868    2   

201619     16          44      21.57  0.4277  3.865e-07   4.76     1   
-----------------------------------------------------------------------


```
## Área Programática da Saúde 4.0
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     48          48      23.86  0.2134      0       5.722    2   

201617     342         342     21.86  2.151       1       40.77    2   

201618     21          33      19.86  0.2214      0       3.934    2   

201619     11          30      21.57  0.1811      0       3.576    2   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 5.1
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     387         387     23.86  0.7713  5.771e-05   59.01    2   

201617     383         383     21.86  0.7523  1.167e-05   58.4     2   

201618     79          134     19.86  0.3102      0       20.43    2   

201619     12          33      21.57  0.1044      0       5.031    2   
-----------------------------------------------------------------------




```
## Área Programática da Saúde 5.2
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201616     69          69      23.86  0.7066   0.01287    10.37    2   

201617     69          69      21.86  0.7492   0.03377    10.37    2   

201618     23          36      19.86  0.4646  3.818e-05   5.412    2   

201619     23          66      21.57  1.053     0.6161    9.922    1   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 5.3
```

<br> </br>



-------------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt     prob(Rt>1)   inc    nivel 
------ ----------- ----------- ------ ------- ------------ ------ -------
201616     83          83      23.86  0.9425     0.3488    22.52     2   

201617     58          58      21.86  0.6394    0.003455   15.74     2   

201618      9          13      19.86  0.1655   1.943e-13   3.527     2   

201619      1           1      21.57  0.01902   2.22e-16   0.2713    2   
-------------------------------------------------------------------------
[volta](#top)

<br> </br>


\newpage

### Notas {#notas}


- Os dados do sinan mais recentes ainda não foram totalmente digitados. Estimamos o número esperado de casos
notificados considerando o tempo ate os casos serem digitados.
- Os dados de tweets são gerados pelo Observatório de Dengue (UFMG). Os tweets são processados para exclusão de informes e outros temas relacionados a dengue
- Algumas vezes, os casos da última semana ainda não estao disponiveis, nesse caso, usa-se uma estimação com base na tendência de variação da serie 

Créditos
------
Esse e um projeto desenvolvido em parceria pela Fiocruz, FGV e Prefeitura do Rio de Janeiro, com apoio da SVS/MS

Mais detalhes do projeto , ver: [www.dengue.mat.br](www.dengue.mat.br) 

<br> </br>
------------
<br> </br>




[volta](#top)
